# Programming-Paradigms-Coursework-2

README for Programming Paradigms Coursework 2 'Langton Ant'

Use "make" to only compile the library "libant.so"

Use "make run" to compile and run the executable. This will use the example rule "LLRR"

To use other rules either change the rule in the make file and use "make run" or in command line use "./ant {rule}"

The basic variant will be ran if no rule supplied from makefile or command line

White and Black are used to visualise the basic variant and letters A-Z for the advanced variant
